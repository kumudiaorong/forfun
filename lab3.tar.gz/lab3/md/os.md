# 练习一 给未被映射的地址映射上物理页

> 前置知识

函数/宏|作用
-|-
le2vma|根据list_entry获取结构体vma指针
find_vma|根据虚拟地址获取vma
ROUNDDOWN|向下取整
pgdir_alloc_page|根据页目录项分配物理页

```c
int do_pgfault(struct mm_struct *mm, uint32_t error_code, uintptr_t addr) {
  int ret = -E_INVAL;
  // try to find a vma which include addr
  struct vma_struct *vma = find_vma(mm, addr);

  pgfault_num++;
  // If the addr is in the range of a mm's vma?
  if (vma == NULL || vma->vm_start > addr) {
    cprintf("not valid addr %x, and  can not find it in vma\n", addr);
    goto failed;
  }
```

根据虚拟地址获取vma，如果vma不存在或者vma的起始地址大于addr，说明addr不在vma的范围内，直接返回错误。

```c
  // check the error_code
  switch (error_code & 3) {
  default:
    /* error code flag : default is 3 ( W/R=1, P=1): write, present */
  case 2: /* error code flag : (W/R=1, P=0): write, not present */
    if (!(vma->vm_flags & VM_WRITE)) {
      cprintf("do_pgfault failed: error code flag = write AND not present, but "
              "the addr's vma cannot write\n");
      goto failed;
    }
    break;
  case 1: /* error code flag : (W/R=0, P=1): read, present */
    cprintf("do_pgfault failed: error code flag = read AND present\n");
    goto failed;
  case 0: /* error code flag : (W/R=0, P=0): read, not present */
    if (!(vma->vm_flags & (VM_READ | VM_EXEC))) {
      cprintf("do_pgfault failed: error code flag = read AND not present, but "
              "the addr's vma cannot read or exec\n");
      goto failed;
    }
  }
  /* IF (write an existed addr ) OR
   *    (write an non_existed addr && addr is writable) OR
   *    (read  an non_existed addr && addr is readable)
   * THEN
   *    continue process
   */
```

根据错误码进行对应处理，如果错误码为2，说明是写错误，如果vma不可写，返回错误。如果错误码为1，说明是读错误，返回错误。如果错误码为0，说明是读错误，如果vma不可读且不可执行，返回错误。

```c
  uint32_t perm = PTE_U;
  if (vma->vm_flags & VM_WRITE) {
    perm |= PTE_W;
  }
  addr = ROUNDDOWN(addr, PGSIZE);

  ret = -E_NO_MEM;

  pte_t *ptep = NULL;

  ptep = get_pte(mm->pgdir, addr, 1);
  if (ptep == NULL) {
    cprintf("get_pte in do_pgfault failed\n");
    goto failed;
  }
  if (*ptep == 0) {
    struct Page *page = pgdir_alloc_page(mm->pgdir, addr, perm);
    if (page == NULL) {
      cprintf("pgdir_alloc_page failed\n");
      goto failed;
    }
  }

  ret = 0;
failed:
  return ret;
}
```

准备好权限，将addr向下取整，根据addr获取页表项或者分配页表，如果页表不存在，分配物理页，返回成功。

### 请描述页目录项（Page Directory Entry）和页表项（Page Table Entry）中组成部分对ucore实现页替换算法的潜在用处。

如果页表项中的PTE_P位为0，说明该页表项对应的物理页不存在，可以将该页表项对应的虚拟页换入

### 如果ucore的缺页服务例程在执行过程中访问内存，出现了页访问异常，请问硬件要做哪些事情？

硬件会将异常访问的地址放入cr2寄存器，然后跳转到缺页异常处理程序

# 练习二 补充完成基于FIFO的页面替换算法

> 前置知识

函数|作用
-|-
swap_in|将硬盘中的物理页换入内存物理页
swapfs_read|从硬盘中读取物理页

```c
static int _fifo_map_swappable(struct mm_struct *mm, uintptr_t addr,
                               struct Page *page, int swap_in) {
  list_entry_t *head = (list_entry_t *)mm->sm_priv;
  list_entry_t *entry = &(page->pra_page_link);

  assert(entry != NULL && head != NULL);
  // record the page access situlation
  /*LAB3 EXERCISE 2: YOUR CODE*/
  //(1)link the most recent arrival page at the back of the pra_list_head
  // qeueue.

  list_add(head, entry);
  return 0;
}
```
将最近访问的页放到链表的最后（链表头部是最近访问的页）

```c
static int _fifo_swap_out_victim(struct mm_struct *mm, struct Page **ptr_page,
                                 int in_tick) {
  list_entry_t *head = (list_entry_t *)mm->sm_priv;
  assert(head != NULL);
  assert(in_tick == 0);

  /* Select the victim */
  /*LAB3 EXERCISE 2: YOUR CODE*/
  //(1)  unlink the  earliest arrival page in front of pra_list_head qeueue
  //(2)  assign the value of *ptr_page to the addr of this page

  list_entry_t *le = list_prev(head);
  assert(le != head);
  list_del(le);
  struct Page *page = le2page(le, pra_page_link);
  assert(page != NULL);
  *ptr_page = page;
  return 0;
}
```
取出链表头部的页，作为换出页，删除该页，将该页的地址赋值给ptr_page
```c
  else{
    if(swap_init_ok){
      struct Page *page = NULL;
      if((ret = swap_in(mm, addr, &page)) != 0){
        cprintf("swap_in failed\n");
        goto failed;
      }
      page->pra_vaddr = addr;
      page_insert(mm->pgdir, page, addr, perm);
      swap_map_swappable(mm, addr, page, 1);
    }
    else{
      cprintf("no swap_init_ok but ptep is %x, failed\n",*ptep);
      goto failed;
    }
  }
```
判断是否初始化成功，如果成功，将硬盘中的物理页换入内存物理页，如果失败，返回错误。如果换入成功，则将该页插入页表，将该页标记为可换出。
# 拓展练习：实现识别dirty bit的 extended clock页替换算法

由于enhanced clock算法的实现和FIFO算法的实现类似，所以只需要实现识别dirty bit的功能即可。可修改swap_fifo.c中最后两个函数，实现enhandced clock算法，并检查测试结果。
```c
static int _enhanced_clock_swap_out_victim(struct mm_struct *mm,
                                           struct Page **ptr_page,
                                           int in_tick) {
  list_entry_t *head = (list_entry_t *)mm->sm_priv;
  assert(head != NULL);
  assert(in_tick == 0);

  list_entry_t *le = list_next(head);
  assert(le != head);

  list_entry_t *all_victim[4] = {};
  struct Page *page = NULL;
  while (le != head) {
    struct Page *page = le2page(le, pra_page_link);
    pte_t *ptep = get_pte(mm->pgdir, page->pra_vaddr, 0);
    all_victim[((!!((*ptep) & PTE_A)) << 1) + (!!((*ptep) & PTE_D))] = le;
    le = list_next(le);
  }
  for (int i = 0; i < 4; i++) {
    if (all_victim[i] != NULL) {
      page = le2page(all_victim[i], pra_page_link);
      assert(page != NULL);
      le = all_victim[i];
      break;
    }
  }
  list_del(le);
  *ptr_page = page;
  return 0;
}
```
从头遍历链表，将链表中的页按照是否被访问和是否被修改分为四类（实际上只有三类，因为修改一般伴随访问），再从四类中选取优先级最高的删除
```c
static void check_swap(void) {
  ...
  for (i = 0; i < CHECK_VALID_PHY_PAGE_NUM; i++) {
    check_ptep[i] = 0;
    check_ptep[i] = get_pte(pgdir, (i + 1) * 0x1000, 0);
    // cprintf("i %d, check_ptep addr %x, value %x\n", i, check_ptep[i],
    // *check_ptep[i]);
    assert(check_ptep[i] != NULL);
    assert(pte2page(*check_ptep[i]) == check_rp[i]);
    assert((*check_ptep[i] & PTE_P));
    if (i == 1)
      *check_ptep[i] &= ~(PTE_D);
    if (i == 2)
      *check_ptep[i] &= ~(PTE_A);
    if (i == 3)
      *check_ptep[i] &= ~(PTE_A | PTE_D);
  }
  ...
}
static int _enhanced_clock_check_swap(void) {
  unsigned char c;
  cprintf("write Virt Page e in fifo_check_swap\n");
  *(unsigned char *)0x5000 = 0x0e;
  assert(pgfault_num == 5);
  cprintf("write Virt Page d in fifo_check_swap\n");
  *(unsigned char *)0x4000 = 0x0d;
  assert(pgfault_num == 6);
  cprintf("write Virt Page c in fifo_check_swap\n");
  *(unsigned char *)0x3000 = 0x0c;
  assert(pgfault_num == 7);
  cprintf("write Virt Page b in fifo_check_swap\n");
  *(unsigned char *)0x2000 = 0x0b;
  assert(pgfault_num == 8);
  return 0;
}
```
根据`check_swap`与`check_content_set`知内存页限定为四页，且已经预先访问过一次，顺序为a,b,c,d,手动设置页表项为四种情况（11：访问且修改，10：访问不修改，01：未访问且修改，00：未访问不修改）
- 当写e时，a，b，c，d中d优先级最高（00），换出
- 当写d时，a，b，c，e中c优先级最高（01），换出
- 当写c时，a，b，d，e中b优先级最高（10），换出
- 当写b时，a，b，c，d优先级相同，换出a
```
set up init env for check_swap over!
write Virt Page e in fifo_check_swap
page fault at 0x00005000: K/W [no page found].
swap_out: i 0, store page in vaddr 0x4000 to disk swap entry 5
write Virt Page d in fifo_check_swap
page fault at 0x00004000: K/W [no page found].
swap_out: i 0, store page in vaddr 0x3000 to disk swap entry 4
swap_in: load disk swap entry 5 with swap_page in vadr 0x4000
write Virt Page c in fifo_check_swap
page fault at 0x00003000: K/W [no page found].
swap_out: i 0, store page in vaddr 0x2000 to disk swap entry 3
swap_in: load disk swap entry 4 with swap_page in vadr 0x3000
write Virt Page b in fifo_check_swap
page fault at 0x00002000: K/W [no page found].
swap_out: i 0, store page in vaddr 0x1000 to disk swap entry 2
swap_in: load disk swap entry 3 with swap_page in vadr 0x2000
count is 0, total is 7
check_swap() succeeded!
```

### 需要被换出的页的特征是什么？
根据页的优先级，先判断是否被访问，再判断是否被修改
### 在ucore中如何判断具有这样特征的页？
根据页表项的`PTE_A`和`PTE_D`位
### 何时进行换入和换出操作？
当页表项的`PTE_P`位为0时，说明页不在内存中，需要换入；
当系统主动调用`swap_out`函数或者发生缺页异常时，需要换出
# 参考答案对比
### 练习1: 
与参考答案基本相同
### 练习2：
除个别细节执行顺序不同外，与参考答案相同

# 重要知识点和对应原理
### 实验
- 页访问异常的处理
- 按需分页
- FIFO页替换算法
- Enhanced Clock页替换算法
### 对应的OS原理知识点
- 页访问异常的处理
- 按需分页
- FIFO页替换算法
### 未对应的知识点
- 进程相关知识点
- 文件系统相关知识点